const activity = require('./data/d1.json');

// function compare(a, b) {
//   if (a.rating < b.rating) return 1;
//   if (a.rating > b.rating) return -1;
//   return 0;
// }
function shuffle(a) {
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
// 1. recherche titre
// 2. coup de coeur
// 3. categorie
// 4. taille du livre
// 5. trié par rating
const findActivity = async function findActivity(event) {
  if (event.id) {
    const book = activity.filter((b) => (b.id === event.id));
    if (book.length > 0) return book[0];
  }

  let res = activity;
  console.log(res.length);
  if (event.category && event.category.length > 0) {
    res = res.filter((b) => b.fields.category.indexOf(event.category) !== -1);
  }
  console.log(res.length);
  if (event.price && event.price.length > 0) {
    res = res.filter((b) => {
      console.log('b.price_type', b.price_type);
      console.log('event.price', event.price);
      return (b.fields.price_type === event.price);
    });
  }
  return shuffle(res).slice(0, 5);
};
exports.handler = async (event) => findActivity(event);
